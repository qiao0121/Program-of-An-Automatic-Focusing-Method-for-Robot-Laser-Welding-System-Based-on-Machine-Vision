function edge_image = canny_edge_detection(input_image, low_threshold, high_threshold)
    % ����ͼ��
    grayscale_image = rgb2gray(input_image);

    % ��˹�˲�
    filtered_image = imgaussfilt(grayscale_image, 1);
 
    % �����ݶȷ�ֵ�ͷ���
    [gradient_magnitude, gradient_direction] = imgradient(filtered_image);

    % �Ǽ���ֵ����
    suppressed_image = non_maximum_suppression(gradient_magnitude, gradient_direction);

    % ˫��ֵ���
    edge_image = double_thresholding(suppressed_image, low_threshold, high_threshold);
     
    % ����任
    [centers, radii] = imfindcircles(edge_image, [20 100], 'ObjectPolarity', 'bright', 'Sensitivity', 0.9);

    % ��ԭʼͼ���ϻ��Ƽ�⵽��Բ
    imshow(input_image);
    hold on;
    viscircles(centers, radii, 'EdgeColor', 'r');
    hold off;
end

function suppressed_image = non_maximum_suppression(gradient_magnitude, gradient_direction)
    [height, width] = size(gradient_magnitude);
    suppressed_image = zeros(height, width);

    for i = 2:(height-1)
        for j = 2:(width-1)
            angle = gradient_direction(i, j);
            q = gradient_magnitude(i, j+1);
            r = gradient_magnitude(i, j-1);

            % �����ݶȷ�����в�ֵ
            if ((angle >= -22.5 && angle <= 22.5) || (angle >= 157.5 && angle <= 180) || (angle >= -180 && angle <= -157.5))
                p = gradient_magnitude(i+1, j);
                s = gradient_magnitude(i-1, j);
            elseif ((angle > 22.5 && angle < 67.5) || (angle > -157.5 && angle < -112.5))
                p = gradient_magnitude(i+1, j+1);
                s = gradient_magnitude(i-1, j-1);
            elseif ((angle >= 67.5 && angle <= 112.5) || (angle >= -112.5 && angle <= -67.5))
                p = gradient_magnitude(i, j+1);
                s = gradient_magnitude(i, j-1);
            else
                p = gradient_magnitude(i-1, j+1);
                s = gradient_magnitude(i+1, j-1);
            end

            % ���зǼ���ֵ����
            if (gradient_magnitude(i, j) >= p && gradient_magnitude(i, j) >= s)
                suppressed_image(i, j) = gradient_magnitude(i, j);
            end
        end
    end
end

function edge_image = double_thresholding(image, low_threshold, high_threshold)
    [height, width] = size(image);
    edge_image = zeros(height, width);

    % ����ֵ�͵���ֵ
    high_threshold = max(image(:)) * high_threshold;
    low_threshold = high_threshold * low_threshold;

    % ˫��ֵ���
    strong_edge_row = [];
    strong_edge_col = [];
    weak_edge_row = [];
    weak_edge_col = [];

    for i = 2:(height-1)
        for j = 2:(width-1)
            if (image(i, j) >= high_threshold)
                strong_edge_row = [strong_edge_row i];
                strong_edge_col = [strong_edge_col j];
                edge_image(i, j) = 1;
            elseif (image(i, j) >= low_threshold)
                weak_edge_row = [weak_edge_row i];
                weak_edge_col = [weak_edge_col j];
            end
        end
    end

    % ǿ��Ե����
    for k = 1:length(strong_edge_row)
        i = strong_edge_row(k);
        j = strong_edge_col(k);
        edge_image = follow_edges(edge_image, weak_edge_row, weak_edge_col, i, j);
    end
end

function edge_image = follow_edges(edge_image, weak_edge_row, weak_edge_col, i, j)
    [height, width] = size(edge_image);

    for m = -1:1
        for n = -1:1
            if (i+m >= 1 && i+m <= height && j+n >= 1 && j+n <= width)
                if (edge_image(i+m, j+n) == 0 && ~isempty(find(weak_edge_row == (i+m) & weak_edge_col == (j+n), 1)))
                    edge_image(i+m, j+n) = 1;
                    edge_image = follow_edges(edge_image, weak_edge_row, weak_edge_col, i+m, j+n);
                end
            end
        end
    end
end

function edge_image = edge_fitting(edge_image)
    [rows, cols] = find(edge_image);

    % ��ÿ��ǿ��Ե���ؽ��б�Ե���
    for i = 1:length(rows)
        x = cols(i);
        y = rows(i);

        % �ڴ˴�ʵ�ֱ�Ե����㷨������ֱ�����
        % ����ʹ�� polyfit ����ֱ�����
        [p, ~] = polyfit(x, y, 1);

        % ������ϵ�ֱ�ߣ�����ÿһ�е�Ԥ��ֵ
        fitted_y = polyval(p, 1:size(edge_image, 2));

        % ���� edge_image������ϵı�Ե��������Ϊ1
        edge_image(round(fitted_y), 1:size(edge_image, 2)) = 1;
    end
end

function [center_x, center_y, radius] = fit_circle(edge_image)
    % ʹ��Hough�任���Բ
    [centers, radii, ~] = imfindcircles(edge_image, [10, 30]);

    % ѡ�����Բ
    [~, index] = max(radii);
    center_x = centers(index, 1);
    center_y = centers(index, 2);
    radius = radii(index);
end