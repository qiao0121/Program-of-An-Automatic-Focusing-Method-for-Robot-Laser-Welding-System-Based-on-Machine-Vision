function sharpness = evaluate_image_clarity_laplacian(image)
    % image: ������ͼ��
    gray_image = rgb2gray(image);
    laplacian_filter = [0 -1 0; -1 4 -1; 0 -1 0];
    laplacian_result = imfilter(gray_image, laplacian_filter);
    sharpness = mean(abs(laplacian_result(:)));
end