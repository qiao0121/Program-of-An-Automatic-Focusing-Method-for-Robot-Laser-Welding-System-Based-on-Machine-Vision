function sharpness = evaluate_image_clarity_roberts(image)
    % image: ������ͼ��
    gray_image = rgb2gray(image);
    gradient_x = edge(gray_image, 'Roberts', 0.01);
    gradient_y = edge(gray_image, 'Roberts', 0.01);
    sharpness = sum(abs(gradient_x(:))) + sum(abs(gradient_y(:)));
end