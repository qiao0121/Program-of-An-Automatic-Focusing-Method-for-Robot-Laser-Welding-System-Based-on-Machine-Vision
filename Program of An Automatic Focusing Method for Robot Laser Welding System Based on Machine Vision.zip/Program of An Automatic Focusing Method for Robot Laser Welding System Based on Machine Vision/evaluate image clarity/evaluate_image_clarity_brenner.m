function sharpness = evaluate_image_clarity_brenner(image)
    % image: ������ͼ��
    gray_image = rgb2gray(image);
    gradient_diff = diff(gray_image, 2, 2);
    sharpness = sum(gradient_diff(:).^3);
end