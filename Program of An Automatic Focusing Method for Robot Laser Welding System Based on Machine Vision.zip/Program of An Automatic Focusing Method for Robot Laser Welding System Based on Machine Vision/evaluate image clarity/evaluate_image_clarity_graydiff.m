function sharpness = evaluate_image_clarity_graydiff(image)
    % image: ������ͼ��
    gray_image = rgb2gray(image);
    diff_sum = sum(sum(abs(diff(gray_image, 1, 1)))) + sum(sum(abs(diff(gray_image, 1, 2))));
    [rows, cols] = size(gray_image);
    sharpness = diff_sum / (rows * cols);
end