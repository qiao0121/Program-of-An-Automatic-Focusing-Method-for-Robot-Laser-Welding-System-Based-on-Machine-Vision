function sharpness = evaluate_image_clarity_kirsch(image)
    % image: ������ͼ��
    gray_image = rgb2gray(image);
    kirsch_mask = [
        [-3, -3, 5; -3, 0, 5; -3, -3, 5],   % Direction 0
        [-3, 5, 5; -3, 0, 5; -3, -3, -3],   % Direction 45
        [5, 5, 5; -3, 0, -3; -3, -3, -3],   % Direction 90
        [5, 5, -3; 5, 0, -3; -3, -3, -3],   % Direction 135
        [5, -3, -3; 5, 0, -3; 5, -3, -3],   % Direction 180
        [-3, -3, -3; 5, 0, -3; 5, 5, -3],   % Direction 225
        [-3, -3, -3; -3, 0, -3; 5, 5, 5],   % Direction 270
        [-3, -3, -3; -3, 0, 5; -3, 5, 5]    % Direction 315
    ];
    gradient_kirsch = imfilter(gray_image, kirsch_mask);
    sharpness = sum(abs(gradient_kirsch(:)));
end