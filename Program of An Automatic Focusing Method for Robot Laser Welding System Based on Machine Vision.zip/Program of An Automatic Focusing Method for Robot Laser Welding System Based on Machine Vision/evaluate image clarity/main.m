% ����ͼ�������Ȳ���¼���������ʱ��
sharpness_scores = zeros(20, 6);
execution_times = zeros(6, 1);

for i = 1:21
    % ��ȡ������ͼ��
    image = imread(sprintf('image_%d.jpg', i));
    
    % ����ͼ�������Ⱥͼ�������ʱ��
    tic;
    sharpness_scores(i, 1) = evaluate_image_clarity_graydiff(image);
    execution_times(1) = execution_times(1) + toc;
    
    tic;
    sharpness_scores(i, 2) = evaluate_image_clarity_tenengrad(image);
    execution_times(2) = execution_times(2) + toc;
    
    tic;
    sharpness_scores(i, 3) = evaluate_image_clarity_roberts(image);
    execution_times(3) = execution_times(3) + toc;
    
    tic;
    sharpness_scores(i, 4) = evaluate_image_clarity_kirsch(image);
    execution_times(4) = execution_times(4) + toc;
    
    tic;
    sharpness_scores(i, 5) = evaluate_image_clarity_brenner(image);
    execution_times(5) = execution_times(5) + toc;
    
    tic;
    sharpness_scores(i, 6) = evaluate_image_clarity_laplacian(image);
    execution_times(6) = execution_times(6) + toc;
end

% ��һ������
sharpness_scores_normalized = normalize(sharpness_scores, 'range');

% ��������ͼ
figure;
plot(1:21, sharpness_scores_normalized(:, 1), 'ro-'); hold on;
plot(1:21, sharpness_scores_normalized(:, 2), 'go-');
plot(1:21, sharpness_scores_normalized(:, 3), 'bo-');
plot(1:21, sharpness_scores_normalized(:, 4), 'co-');
plot(1:21, sharpness_scores_normalized(:, 5), 'mo-');
plot(1:21, sharpness_scores_normalized(:, 6), 'yo-');
xlabel('���λ��x/mm');
ylabel('��һ�����ͼ��������');
title('Image Sharpness Scores');
legend('Graydiff', 'Tenengrad', 'Roberts', 'Kirsch', 'Brenner', 'Laplacian', 'Location', 'best');

% ��ʾ����ʱ��
fprintf('Execution times (in seconds):\n');
fprintf('  Graydiff: %.4f\n', execution_times(1));
fprintf('  Tenengrad: %.4f\n', execution_times(2));
fprintf('  Roberts: %.4f\n', execution_times(3));
fprintf('  Kirsch: %.4f\n', execution_times(4));
fprintf('  Brenner: %.4f\n', execution_times(5));
fprintf('  Laplacian: %.4f\n', execution_times(6));
