function sharpness = evaluate_image_clarity_tenengrad(image)
    % image: ������ͼ��
    gray_image = rgb2gray(image);
    gradients = imgradient(gray_image);
    sharpness = mean(gradients(:).^2);
end